1.First Compile and Run Server.c(PORT NUMBER Should Be Same In Both CLIENT.c and SERVER.C)
2.It will Show "Waiting for Connection"
3.Now, Run Client.c 
4.You can also Run Client.c in different terminal for multiple User access
5.Now give "ls , put file1.txt (transfer file to server)"
6.You will Show some activity in server terminal i.e. Connection accepted or Received ls 
